//
//  main.m
//  TweetyGonzalez
//
//  Created by YOUR NAME on 2009-05-12.
//  Copyright (c) 2007 YOUR NAME. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <RubyCocoa/RBRuntime.h>

int main(int argc, const char *argv[])
{
    return RBApplicationMain("rb_main.rb", argc, argv);
}
