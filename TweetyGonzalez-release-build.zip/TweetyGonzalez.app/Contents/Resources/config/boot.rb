require File.dirname(__FILE__) + '/environment.rb'
