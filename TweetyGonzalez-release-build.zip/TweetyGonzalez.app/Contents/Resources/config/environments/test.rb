# Perform any test specific task here.

Rucola::Initializer.run do |config|
  # The debugger allows you to easily set breakpoints and debug them.
  # See the documentation from ruby-debug for its usage:
  # http://www.datanoise.com/ruby-debug/
  
  # config.use_debugger = true
end